function [PCS,EOC]=NA(k,T,n0,num,p,bw)
tic
mu1=zeros(1,k);
alpha1=3*ones(1,k);
kappa1=3*ones(1,k);
beta1=6*ones(1,k);
alpha2=3*ones(1,k);
beta2=ones(1,k);
Mean=zeros(1,k);
Var=zeros(1,k);
Lambda=zeros(1,k);
N0=1000;

  
PCS=zeros(1,T);
EOC=zeros(1,T);
AV=zeros(1,k);
wt=zeros(1,k);
delta=zeros(1,k);
x=zeros(T,k);
for t=1:num
    N=n0*ones(1,k);
Qt=zeros(1,k);
for j=1:k
   Pres=gamrnd(alpha1(j),1/beta1(j),1,1);
 Var(j)=1./ Pres;
 sigma1=(kappa1(j)* Pres).^(-1/2);
 Mean(j)=normrnd(mu1(j),sigma1);
 Lambda(j)=gamrnd(alpha2(j),1/beta2(j),1,1);
 x(1:n0,j)=JDP(Mean(j),Var(j),Lambda(j),n0);
 X=JDP(Mean(j),Var(j),Lambda(j),N0);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end
[~,rb]=max(Qt,[],2);
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
for j=1:k
AV(j)=p*(1-p)/(sum(normpdf(qt(j)*ones(1,N(j)),(x(1:N(j),j))',bw*ones(1,N(j)))))^2;
end
  %qt=m+w.*v.^(1/2);
for i=1:T
     [~,id4]=max(qt);

  
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  [~,O]=max(qt);
[~,o]=min(qt);

  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
df=(k*n0+i)*wt-(k*n0+i-1)*N/sum(N);
 [~,id2]=max(df);
 N(id2)=N(id2)+1;
 x(N(id2),id2)=JDP(Mean(id2),Var(id2),Lambda(id2),1);
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
AV(id2)=p*(1-p)/(sum(normpdf(qt(id2)*ones(1,N(id2)),(x(1:N(id2),id2))',bw*ones(1,N(id2)))))^2;

end
end
toc
end