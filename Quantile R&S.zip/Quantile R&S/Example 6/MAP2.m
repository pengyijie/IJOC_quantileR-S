function [PCS,EOC]=MAP2(k,T,n0,num,p)
tic
w=norminv(p,0,1);
mu1=zeros(1,k);
alpha1=3*ones(1,k);
kappa1=3*ones(1,k);
beta1=6*ones(1,k);
alpha2=3*ones(1,k);
beta2=ones(1,k);
Mean=zeros(1,k);
Var=zeros(1,k);
Lambda=zeros(1,k);
N0=1000;

alpha0=(beta1./(alpha1-1)+alpha2./beta2).^2./(beta1.^2./(alpha1-1).^2./(alpha1-2)+alpha2./(beta2).^2)+2;
  beta0=(alpha0-1).*(beta1./(alpha1-1)+alpha2./beta2);
  mu0=mu1;
  kappa0=(beta1./(alpha1-1)+alpha2./beta2)./(beta1./(alpha1-1)./kappa1);
  
PCS=zeros(1,T);
EOC=zeros(1,T);
for t=1:num
N=n0*ones(1,k);
x=zeros(n0,k);
Qt=zeros(1,k);
%M=zeros(1,k);
for j=1:k
 Pres=gamrnd(alpha1(j),1/beta1(j),1,1);
 Var(j)=1./ Pres;
 sigma1=(kappa1(j)* Pres).^(-1/2);
 Mean(j)=normrnd(mu1(j),sigma1);
 Lambda(j)=gamrnd(alpha2(j),1/beta2(j),1,1);
 x(:,j)=JDP(Mean(j),Var(j),Lambda(j),n0);
 X=JDP(Mean(j),Var(j),Lambda(j),N0);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end

m=mean(x);
v=var(x);
[~,rb]=max(Qt,[],2);

mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  kappa=kappa0+N;
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1)).^(1/2);
  pv=(beta./(alpha.*kappa)).^(1/2);

mv=mu+w*V;
q=max(mv);
r=(q-mu)./pv;

for i=1:T
      [~,id4]=max(mv);
  if id4==rb
   PCS(t,i)=1;
  end
  EOC(t,i)=Qt(rb)-Qt(id4);
  p1=(alpha./(alpha-1)).^(1/2);
 E=pv.*(p1.*tpdf(r./p1,2*alpha)-r.*(1-tcdf(r,2*alpha)));
if p>1/2
 p2=((alpha-1/2)./alpha).^(1/2);   
 %p3=tr*(alpha./(alpha-2)).^(1/2);
 for j=1:k
 %x=(-p3:d:r(j));
 %ll=length(x);
 %xi=(w./(r(j)-x)).^2./pv(j)^(2);
 %eta=beta(j)+kappa(j)*pv(j)^(2)*x.^2/2;
 %y1=(x-r(j)).*gamcdf(xi,(alpha(j)+1/2)*ones(1,ll),1./eta).*tpdf(x,2*alpha(j));
 F1=@(x)(x-r(j)).*gamcdf((w./(r(j)-x)).^2./pv(j)^(2),(alpha(j)+1/2),1./(beta(j)+kappa(j)*pv(j)^(2)*x.^2/2)).*tpdf(x,2*alpha(j));
 %E1=trapz(x,y1);
 E1=integral(F1,-inf,r(j));
 %y2=gamcdf(xi,alpha(j)*ones(1,ll),1./eta).*tpdf(p2(j)*x,2*alpha(j)-1);
 F2=@(x)gamcdf((w./(r(j)-x)).^2./pv(j)^(2),alpha(j),1./(beta(j)+kappa(j)*pv(j)^(2)*x.^2/2)).*tpdf(p2(j)*x,2*alpha(j)-1);
 %E2=trapz(x,y2);
 E2=integral(F2,-inf,r(j));
 E(j)=E(j)+pv(j)*E1+w*V(j)*(1-tcdf(p2(j)*r(j),2*alpha(j)-1)+p2(j)*E2);
 end
else if p<1/2
      p2=((alpha-1/2)./alpha).^(1/2); 
 %p3=5*(alpha./(alpha-2)).^(1/2);
 for j=1:k
 %xx=(r(j):0.01:p3);
 %ll=length(xx);
 %xi=(w./(r(j)-xx)).^2./pv(j)^(2);
 %eta=beta(j)+kappa(j)*pv(j)^(2)*xx.^2/2;
 %y1=(xx-r(j)).*gamcdf(xi,(alpha(j)+1/2)*ones(1,ll),1./eta).*tpdf(xx,2*alpha(j));
 %E11=trapz(xx,y1);
 F1=@(x)(x-r(j)).*gamcdf((w./(r(j)-x)).^2./pv(j)^(2),(alpha(j)+1/2),1./(beta(j)+kappa(j)*pv(j)^(2)*x.^2/2)).*tpdf(x,2*alpha(j));
 E1=integral(F1,r(j),inf);
 %y2=gamcdf(xi,alpha(j)*ones(1,ll),1./eta).*tpdf(p2(j)*xx,2*alpha(j)-1);
 %E22=trapz(xx,y2);
 F2=@(x)gamcdf((w./(r(j)-x)).^2./pv(j)^(2),alpha(j),1./(beta(j)+kappa(j)*pv(j)^(2)*x.^2/2)).*tpdf(p2(j)*x,2*alpha(j)-1);
  E2=integral(F2,r(j),inf);
 E(j)=E(j)-pv(j)*E1+w*V(j)*(1-tcdf(p2(j)*r(j),2*alpha(j)-1)-p2(j)*E2);
 end   
    end
    
end
  [~,id2]=max(E);  
  pm=m(id2);
   x=JDP(Mean(id2),Var(id2),Lambda(id2),1);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;

  mu(id2)=(kappa0(id2).*mu0(id2)+N(id2).*m(id2))./(kappa0(id2)+N(id2));
  kappa(id2)=kappa0(id2)+N(id2);
  alpha(id2)=alpha0(id2)+N(id2)/2;
  beta(id2)=beta0(id2)+(N(id2)/2).*v(id2)+(kappa0(id2).*N(id2).*(m(id2)-mu0(id2)).^2)./(2*(kappa0(id2)+N(id2))); 
  V(id2)=(beta(id2)./(alpha(id2)-1)).^(1/2);
  pv(id2)=(beta(id2)./(alpha(id2).*kappa(id2))).^(1/2);
  mv(id2)=mu(id2)+w*V(id2);
  q=max(mv);
  r=(q-mu)./pv;
  
end
end
toc
end