function [PCS,EOC]=OCBA(k,T,n0,num,p,l)
tic
w=norminv(p,0,1);
mu1=zeros(1,k);
alpha1=3*ones(1,k);
kappa1=3*ones(1,k);
beta1=6*ones(1,k);
alpha2=3*ones(1,k);
beta2=ones(1,k);
Mean=zeros(1,k);
Var=zeros(1,k);
Lambda=zeros(1,k);
N0=1000;

alpha0=(beta1./(alpha1-1)+alpha2./beta2).^2./(beta1.^2./(alpha1-1).^2./(alpha1-2)+alpha2./(beta2).^2)+2;
  beta0=(alpha0-1).*(beta1./(alpha1-1)+alpha2./beta2);
  mu0=mu1;
  kappa0=(beta1./(alpha1-1)+alpha2./beta2)./(beta1./(alpha1-1)./kappa1);
  
PCS=zeros(num,T);
EOC=zeros(num,T);
AV=zeros(1,k);
wt=zeros(1,k);
delta=zeros(1,k);
for t=1:num
N=n0*ones(1,k);
x=zeros(n0,k);
Qt=zeros(1,k);
%M=zeros(1,k);
for j=1:k
 Pres=gamrnd(alpha1(j),1/beta1(j),1,1);
 Var(j)=1./ Pres;
 sigma1=(kappa1(j)* Pres).^(-1/2);
 Mean(j)=normrnd(mu1(j),sigma1);
 Lambda(j)=gamrnd(alpha2(j),1/beta2(j),1,1);
 x(:,j)=JDP(Mean(j),Var(j),Lambda(j),n0);
 X=JDP(Mean(j),Var(j),Lambda(j),N0);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end

m=mean(x);
v=var(x);
[~,rb]=max(Qt,[],2);

m2=v+m.^2;
m3=mean(x.^3);
m4=mean(x.^4);
  qt=m+w*v.^(1/2);
for i=1:T
    if l==1
   mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
V=(beta./(alpha-1)).^(1/2);
  mv=mu+w*V;
  [~,id4]=max(mv);
else
   qt=m+w*v.^(1/2);
  [~,id4]=max(qt);
    end
  if id4==rb
   PCS(t,i)=1;
  end
  EOC(t,i)=Qt(rb)-Qt(id4);
  [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1-w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
AV=abs(AV);
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
id2=find(a);
  x=JDP(Mean(id2),Var(id2),Lambda(id2),1);
  pm=m(id2);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;
m2(id2)=v(id2)+(m(id2)).^2;
m3(id2)=(m3(id2).*N(id2)+x.^3)./(N(id2)+1);
m4(id2)=(m4(id2).*N(id2)+x.^4)./(N(id2)+1);
end
end
toc
end