function x=JDP(Mean,Var,Lambda,n0)
x=normrnd(Mean,Var^(1/2),n0,1);
N=poissrnd(Lambda,n0,1);
y=zeros(n0,1);
for i=1:n0
y(i)=sum(normrnd(0,1,N(i),1));
end
x=x+y;
end