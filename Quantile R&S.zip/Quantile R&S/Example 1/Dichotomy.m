function M=Dichotomy(Var,b,Omega,alpha,A_l,A_u,eps)
wids=(A_u-A_l)/eps;
run=log(wids)/log(2);
x_1=A_l;
x_2=A_u;
h_1=1-sum(Var(b)*Var(Omega)./(alpha(Omega)*x_1-Var(b)).^2);
h_2=1-sum(Var(b)*Var(Omega)./(alpha(Omega)*x_2-Var(b)).^2);
if (h_1<0)&&(h_2<=0)
     M=x_2;
else
for i=1:run  
 x_0=(x_1+x_2)/2;
 h_0=1-sum(Var(b)*Var(Omega)./(alpha(Omega)*x_0-Var(b)).^2);
 if h_0>0
 x_2=x_0;
 else
 x_1=x_0;
 end
end 
M=x_0;
end
end