function [PCS,EOC]=OCBA_C(T,n0,num,alpha0,beta0,mu0,kappa0,p)
tic
k=length(mu0);
PCS=0;
EOC=0;
rep=1;
Mean=zeros(1,k);
Var=zeros(1,k);
AV=zeros(1,k);
w=norminv(p,0,1);
wt=zeros(1,k);
delta=zeros(1,k);
for t=1:num
    x=zeros(n0*k+T,k);
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
x(1:n0,:)=(ones(n0,1)*Mean)+(ones(n0,1)*Var).^(1/2).*repmat(normrnd(0,1,n0,1),1,k);
m=mean(x(1:n0,:));
v=var(x(1:n0,:));
m2=v+m.^2;
m3=mean(x(1:n0,:).^3);
m4=mean(x(1:n0,:).^4);
Del=fix(T/rep);
for r=1:rep
  qt=m+w*v.^(1/2);
  [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1-w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
AN=fix(wt*Del);
AN(O)=fix(AN(O)+Del-sum(AN));
if isreal(AN)==0
    break
end
if sum(AN<0)>0
    break
end
R=repmat(normrnd(0,1,Del,1),1,k);
for j=1:k
    if AN(j)>0
 %if N(j)+AN(j)>k*n0+T
 %end
  %if AN(j)>Del
 %end
x(N(j)+1:N(j)+AN(j),j)=Mean(j)+(Var(j))^(1/2)*R(1:AN(j),j);
 N(j)=N(j)+AN(j);
    end
end
for j=1:k
m(j)=mean(x(1:N(j),j));
v(j)=var(x(1:N(j),j));  
end
       mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
V=(beta./(alpha-1)).^(1/2);
  mv=mu+w*V;
end
  [~,id4]=max(mv);
  if id4==rb 
  PCS=PCS+1/num;
  end
  EOC=EOC+(Qt(rb)-Qt(id4))/num;

end
toc
end