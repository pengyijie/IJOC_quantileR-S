function [M,fail]=Newton(Var,b,Omega,alpha,A_l,A_u,eps,run)
x_1=(A_l+A_u)/2;
M=A_u;
l=0;
fail=0;
while abs(x_1-M)>eps
M=x_1;
dh=1-sum(Var(b)*Var(Omega)./(alpha(Omega)*x_1-Var(b)).^2);
dhh=sum((2*Var(b)*Var(Omega).*alpha(Omega))./(alpha(Omega)*x_1-Var(b)).^3);
x_2=x_1-dh/dhh;
if x_2<A_l
  x_1=A_l+eps;
else if x_2>A_u
     x_1=A_u;
    else
        x_1=x_2;
    end    
end
l=l+1;
if l>run
 fail=1;
 break
end
end
end