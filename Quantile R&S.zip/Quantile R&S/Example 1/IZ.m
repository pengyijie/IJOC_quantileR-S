function [PCS,EOC] = IZ(Qnum,Bnum,n0,T,num,alpha0,beta0,mu0,kappa0,p)
tic
k=length(mu0);
w=norminv(p,0,1);
PCS=zeros(1,T);
EOC=zeros(1,T);
Mean=zeros(1,k);
Var=zeros(1,k);
o=fix(p*Qnum);
for t=1:num
    m=zeros(1,k);
    v=zeros(1,k);
    N=zeros(1,k);
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
for j=1:n0
    for i=1:k
   pm=m(i);
   x=normrnd(Mean(i),Var(i)^(1/2),1,Qnum);
   x=sort(x);
   x=x(o);
  m(i)=(m(i).*N(i)+x)./(N(i)+1);
  v(i)=(N(i)./(N(i)+1)).*(v(i)+(pm-x).^2./(N(i)+1));
  N(i)=N(i)+1; 
    end
end
for j=1:T
       [~,id4]=max(m);
  if id4==rb 
  PCS(j)=PCS(j)+1/num;
  end
  EOC(j)=EOC(j)+(Qt(rb)-Qt(id4))/num;
 wt=v/sum(v);
 aw=N/sum(N);
 [~,id2]=max(wt-aw);
  for i=1:Bnum
     pm=m(id2);
     x=normrnd(Mean(id2),Var(id2)^(1/2),1,Qnum);
   x=sort(x);
   x=x(o);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1)); 
  end
  N(id2)=N(id2)+1;  
end
end
toc
end

