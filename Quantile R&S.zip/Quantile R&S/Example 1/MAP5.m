function [PCS,EOC]=MAP5(T,n0,num,alpha0,beta0,mu0,kappa0,p,a,b)
tic
k=length(mu0);
PCS=zeros(1,T);
EOC=zeros(1,T);
Mean=zeros(1,k);
Var=zeros(1,k);
w=norminv(p,0,1);
for t=1:num
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
x=(ones(n0,1)*Mean)+(ones(n0,1)*Var).^(1/2).*normrnd(0,1,n0,k);
m=mean(x);
v=var(x);

mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  kappa=kappa0+N;
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1/2)).^(1/2);
  pv=((1./kappa+w^2./(alpha-1/2)/2).*beta./(alpha-1)).^(1/2);
Nrv=normrnd(0,1,1,T);

for i=1:T
    mv=mu+w*V;
      [~,id4]=max(mv);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
 
q=max(mv)*ones(1,k);
  [~,s]=min(mv);
 sw=zeros(1,k);
Omega=setdiff((1:k),id4);
alpha=zeros(1,k);
alpha(Omega)=(mv(id4)-mv(Omega)).^2;
sv=N.*pv.^2;
AW1=(sv(Omega)*alpha(s))./(sv(s)*alpha(Omega));
AW2=(sv(id4)./sv(Omega)).*AW1.^2;
sw(s)=1/((sum(AW2))^(1/2)+sum(AW1));
sw(Omega)=AW1*sw(s);
sw(id4)=sw(s)*(sum(AW2))^(1/2);
dd=1./(sum(sv(Omega)./alpha(Omega)));
q(id4)=mv(id4)+(1-a*exp(-b*N(id4)))*sv(id4)*(dd*(1-sw(id4))/sw(id4))^(1/2);
r=(q-mu-w*V)./pv;
    p=(alpha./(alpha-1)).^(1/2);
 E=pv.*(p.*tpdf(r./p,2*alpha)-r.*(1-tcdf(r,2*alpha)));   
% E=pv.*(normpdf(r,0,1)-r.*(1-normcdf(r,0,1)));   
  [~,id2]=max(E);  
  pm=m(id2);
  x=Mean(id2)+(Var(id2)).^(1/2).*Nrv(i);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;

  mu(id2)=(kappa0(id2).*mu0(id2)+N(id2).*m(id2))./(kappa0(id2)+N(id2));
  kappa(id2)=kappa0(id2)+N(id2);
  alpha(id2)=alpha0(id2)+N(id2)/2;
  beta(id2)=beta0(id2)+(N(id2)/2).*v(id2)+(kappa0(id2).*N(id2).*(m(id2)-mu0(id2)).^2)./(2*(kappa0(id2)+N(id2))); 
  V(id2)=(beta(id2)./(alpha(id2)-1)).^(1/2);
  pv(id2)=(beta(id2)./(alpha(id2).*kappa(id2))).^(1/2);
  mv(id2)=mu(id2)+w*V(id2);
  q=max(mv);
  r=(q-mu-w*V)./pv;
  
end
end
toc
end