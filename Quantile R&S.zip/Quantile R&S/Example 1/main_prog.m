function [w,b]=main_prog(Mean,Var,eps,run)
k=length(Mean);
[~,b]=max(Mean);
Omega=setdiff((1:k),b);
alpha=zeros(1,k);
alpha(Omega)=((Mean(Omega)-Mean(b)).^2);
A=(Var(b)+Var(Omega))./alpha(Omega);
A_l=max(Var(b)./alpha(Omega));
A_u=max(A+(k-1)/4*Var(b)./alpha(Omega));
[M,fail]=Newton(Var,b,Omega,alpha,A_l,A_u,eps,run);
if fail==1
    M=Dichotomy(Var,b,Omega,alpha,A_l,A_u,eps);
end
w(b)=(1+sum(Var(Omega)./(alpha(Omega)*M-Var(b))))^(-1);
w(Omega)=w(b)*Var(Omega)./(alpha(Omega)*M-Var(b));
end