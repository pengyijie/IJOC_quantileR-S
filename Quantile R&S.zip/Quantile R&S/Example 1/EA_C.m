function [PCS,EOC]=EA_C(T,n0,num,alpha0,beta0,mu0,kappa0,p)
tic
k=length(mu0);
PCS=0;
EOC=0;
Mean=zeros(1,k);
Var=zeros(1,k);
w=norminv(p,0,1);
for t=1:num
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
AN=fix(T/k);
N=(n0+AN)*ones(1,k);
x=(ones(n0+AN,1)*Mean)+(ones(n0+AN,1)*Var).^(1/2).*repmat(normrnd(0,1,n0+AN,1),1,k);
m=mean(x);
v=var(x);
    mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1)).^(1/2);
  mv=mu+w*V;
  [~,id4]=max(mv);
  if id4==rb 
  PCS=PCS+1/num;
  end
  EOC=EOC+(Qt(rb)-Qt(id4))/num;
end
toc
end