function [PCS,EOC]=MAP8(T,n0,num,alpha0,beta0,mu0,kappa0,p,bw)
tic
k=length(mu0);
PCS=zeros(1,T);
EOC=zeros(1,T);
Mean=zeros(1,k);
Var=zeros(1,k);
x=zeros(T,k);
AV=zeros(1,k);
w=norminv(p,0,1);
for t=1:num
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
x(1:n0,:)=(ones(n0,1)*Mean)+(ones(n0,1)*Var).^(1/2).*normrnd(0,1,n0,k);
m=mean(x(1:n0,:));
v=var(x(1:n0,:));
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
for j=1:k
AV(j)=p*(1-p)/(sum(normpdf(qt(j)*ones(1,N(j)),(x(1:N(j),j))',bw*ones(1,N(j)))))^2;
end
Nrv=normrnd(0,1,1,T);
alpha=alpha0+N/2;
for i=1:T
    q=max(qt);
    pv=(AV./N).^(1/2);
r=(q-qt)./pv;
        qe=m+w*v.^(1/2);
  %[~,id4]=max(qt);
 [~,id4]=max(qe);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  
  z=(alpha./(alpha-1)).^(1/2);
 E=pv.*(z.*tpdf(r./z,2*alpha)-r.*(1-tcdf(r,2*alpha)));   
% E=pv.*(normpdf(r)-r.*(1-normcdf(r)));   
  [~,id2]=max(E);  

  N(id2)=N(id2)+1;
  alpha(id2)=alpha0(id2)+N(id2)/2;
     x(N(id2),id2)=Mean(id2)+(Var(id2)).^(1/2).*Nrv(i);
     pm=m(id2);
  m(id2)=(m(id2).*N(id2)+x(N(id2),id2))./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x(N(id2),id2)).^2./(N(id2)+1));
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
AV(id2)=p*(1-p)/(sum(normpdf(qt(id2)*ones(1,N(id2)),(x(1:N(id2),id2))',bw*ones(1,N(id2)))))^2;
  
end
end
toc
end