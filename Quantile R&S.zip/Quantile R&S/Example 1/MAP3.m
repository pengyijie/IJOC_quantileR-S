function [PCS,EOC]=MAP3(T,n0,num,alpha0,beta0,mu0,kappa0,p)
tic
k=length(mu0);
PCS=zeros(1,T);
EOC=zeros(1,T);
Mean=zeros(1,k);
Var=zeros(1,k);
w=norminv(p,0,1);
for t=1:num
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
x=(ones(n0,1)*Mean)+(ones(n0,1)*Var).^(1/2).*normrnd(0,1,n0,k);
m=mean(x);
v=var(x);

mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  kappa=kappa0+N;
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1)).^(1/2);
  pv=(beta./(alpha.*kappa)).^(1/2);
Nrv=normrnd(0,1,1,T);
mv=mu+w*V;
q=max(mv);
r=(q-mu-w*v.^(1/2))./pv;

for i=1:T
      [~,id4]=max(mv);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  z=(alpha./(alpha-1)).^(1/2);
 E=pv.*(z.*tpdf(r./z,2*alpha)-r.*(1-tcdf(r,2*alpha)));   
  [~,id2]=max(E);  
  pm=m(id2);
  x=Mean(id2)+(Var(id2)).^(1/2).*Nrv(i);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;

  mu(id2)=(kappa0(id2).*mu0(id2)+N(id2).*m(id2))./(kappa0(id2)+N(id2));
  kappa(id2)=kappa0(id2)+N(id2);
  alpha(id2)=alpha0(id2)+N(id2)/2;
  beta(id2)=beta0(id2)+(N(id2)/2).*v(id2)+(kappa0(id2).*N(id2).*(m(id2)-mu0(id2)).^2)./(2*(kappa0(id2)+N(id2))); 
  V(id2)=(beta(id2)./(alpha(id2)-1)).^(1/2);
  pv(id2)=(beta(id2)./(alpha(id2).*kappa(id2))).^(1/2);
  mv(id2)=mu(id2)+w*V(id2);
  q=max(mv);
  r=(q-mu-w*v.^(1/2))./pv;
  
end
end
toc
end