function [PCS,EOC]=MAP(a0,b0,y,T,n0,num,p)
tic
k=length(a0);
PCS=zeros(1,T);
EOC=zeros(1,T);
E=zeros(1,k);
for t=1:num
alpha=gamrnd(a0,1./b0,1,k);
Qt=y./(1-p).^(1./alpha);
[~,rb]=max(Qt);
%N=n0*ones(1,k);
a=a0+n0;
c1=1./alpha;
c2=y./alpha;
c3=y*ones(1,k);
X=gprnd(repmat(c1,n0,1),repmat(c2,n0,1),repmat(c3,n0,1),n0,k);
b=b0+sum(log(X(1:n0,:))/y);
for i=1:T
  qt=y./(1-p).^(b./a);
  r=-log(1-p)/log(max(qt)/y);
  S=gamcdf(r,a,1./b);
  [~,id4]=max(S);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  if sum(isinf(Qt))==0
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  end
  for j=1:k
  Omega=setdiff((1:k),j);
  C=max(gamcdf(r,a(Omega),1./b(Omega)));
  F=@(x,z) max(C,gamcdf(r,a(j)+1,1./(b(j)+log(x./y)))).*z.*y.^z./x.^(z+1).*gampdf(z,a(j),1./b(j));
  E(j)=quad2d(F,y,10^2,0,10^2);
  end
 %E=r.*(gamcdf(1/qt(id4)*ones(1,k),a-1,1./b));   
  [~,id2]=max(E);  
  %N(id2)=N(id2)+1;
 a(id2)=a(id2)+1;
  b(id2)=b(id2)+log(gprnd(c1(id2),c2(id2),c3(id2)))/y;
end
end
toc
end