function [PCS,EOC,CN]=MAP(T,n0,num,alpha0,beta0,mu0,kappa0,p,l)
tic
k=length(mu0);
PCS=zeros(1,T);
EOC=zeros(1,T);
Mean=zeros(1,k);
Var=zeros(1,k);
AV=zeros(1,k);
w=norminv(p,0,1);
wt=zeros(1,k);
delta=zeros(1,k);
CN=zeros(T,k);
for t=1:num
for i=1:k
 Pres=gamrnd(alpha0(i),1/beta0(i),1,1);
 Var(i)=1./ Pres;
 sigma0=(kappa0(i)* Pres).^(-1/2);
 Mean(i)=normrnd(mu0(i),sigma0);
end
Qt=Mean+w*Var.^(1/2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
x=(ones(n0,1)*Mean)+(ones(n0,1)*Var).^(1/2).*normrnd(0,1,n0,k);
m=mean(x);
v=var(x);
if l==1
m2=v+m.^2;
m3=mean(x.^3);
m4=mean(x.^4);
end
mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  kappa=kappa0+N;
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1)).^(1/2);
Nrv=normrnd(0,1,1,T);
E=zeros(1,k);
c1=zeros(1,k);
mv=mu+w*V;
l2=0;
L=0;
for i=1:T
      [~,id4]=max(mv);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  [~,ord]=sort(Qt);
  CN(i,:)=CN(i,:)+N(ord)/num;
  for j=1:k
  id1=setdiff((1:k),j);
  c1(j)=max(mv(id1));
  end
  z0=(beta./(alpha-1)).^(1/2);
  z1_1=N.*m.^2./(2*(N+1).*(alpha-1/2));
  z1_2=(kappa0.*N.^2.*(m-mu0).^2+kappa0.*mu0.^2)./(2*(N+1).*(alpha-1/2).*(kappa+1));
  z1_3=(beta0+N.*v/2)./(alpha-1/2);
  z1_4=mu0.*kappa0.*N.*(m-mu0)./((N+1).*(alpha-1/2).*(kappa+1));
  z1=(z1_1+z1_2+z1_3-z1_4)./z0/2+z0/2;
  z2_1=(kappa0.*N.*(m-mu0)-kappa0.*mu0)./((N+1).*(alpha-1/2).*(kappa+1));
  z2_2=N.*m./((N+1).*(alpha-1/2));
  z2=(z2_1-z2_2)./z0/2;
  z3_1=kappa0./(2*(N+1).*(alpha-1/2).*(kappa+1));
  z3_2=N./(2*(N+1).*(alpha-1/2));
  z3=(z3_1+z3_2)./z0/2;
  c2=mu+w*(z1+z2.*mu+z3.*mu.^2);
  c=c2-c1;
  b1=(beta.*(kappa+1)./(alpha.*kappa)).^(1/2);
  b=b1./(kappa+1)+w*b1.*(z2+2*z3.*mu);
  d=w*z3.*b1.^2;
  nu=2*alpha;
  dr=b.^2-4*d.*c;
  if p>1/2
  l1=l2;
  S1=(dr>0);
  S2=(dr<=0);
  l2=find(S2);
  if l1==l2
      L=L+1;
  else
      L=0;
  end
  if (L>100)&&(l==1)
    qt=m+w*v.^(1/2);
  [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1+w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
id2=find(a);
  else
  u1=-2*c(S1)./(b(S1)-dr(S1).^(1/2));
  u2=-2*c(S1)./(b(S1)+dr(S1).^(1/2));
  Ex1=c2(S1)-c(S1).*(tcdf(u2,nu(S1))-tcdf(u1,nu(S1)));
  Ex2=b(S1).*(nu(S1)./(nu(S1)-2)).^(1/2).*(tpdf(((nu(S1)-2)./nu(S1)).^(1/2).*u2,nu(S1)-2)-tpdf(((nu(S1)-2)./nu(S1)).^(1/2).*u1,nu(S1)-2));
  Ex3=d(S1).*(nu(S1)./(nu(S1)-2)).^(1/2).*(u2.*tpdf(((nu(S1)-2)./nu(S1)).^(1/2).*u2,nu(S1)-2)-u1.*tpdf(((nu(S1)-2)./nu(S1)).^(1/2).*u1,nu(S1)-2));
  Ex4=d(S1).*(nu(S1)./(nu(S1)-2)).*(1-(tcdf(((nu(S1)-2)./nu(S1)).^(1/2).*u2,nu(S1)-2)-tcdf(((nu(S1)-2)./nu(S1)).^(1/2).*u1,nu(S1)-2)));
  E(S1)=Ex1+Ex2+Ex3+Ex4-max(mv);
  E(S2)=c2(S2)+d(S2).*nu(S2)./(nu(S2)-2)-max(mv);
    [~,id2]=max(E);
  end  
  else
      if p==1/2
          r=-c./b;
 E=c2-c.*tcdf(r,nu)+b.*(nu./(nu-2)).^(1/2).*tpdf(((nu-2)./nu).^(1/2).*r,nu-2);
   [~,id2]=max(E);
      else
          %l1=l2;
          S4=(dr>0);
  S5=(dr<=0);
    l2=find(S4);
  if length(l2)==1
      L=L+1;
  end
    if (L>100)&&(l==1)
    qt=m+w*v.^(1/2);
  [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1+w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
id2=find(a);
  else
    u2=-2*c(S4)./(b(S4)-dr(S4).^(1/2));
  u1=-2*c(S4)./(b(S4)+dr(S4).^(1/2));
  Ex1=c2(S4)-c(S4).*(1-tcdf(u2,nu(S4))+tcdf(u1,nu(S4)));
  Ex2=-b(S4).*(nu(S4)./(nu(S4)-2)).^(1/2).*(tpdf(((nu(S4)-2)./nu(S4)).^(1/2).*u2,nu(S4)-2)-tpdf(((nu(S4)-2)./nu(S4)).^(1/2).*u1,nu(S4)-2));
  Ex3=-d(S4).*(nu(S4)./(nu(S4)-2)).^(1/2).*(u2.*tpdf(((nu(S4)-2)./nu(S4)).^(1/2).*u2,nu(S4)-2)-u1.*tpdf(((nu(S4)-2)./nu(S4)).^(1/2).*u1,nu(S4)-2));
  Ex4=d(S4).*(nu(S4)./(nu(S4)-2)).*(tcdf(((nu(S4)-2)./nu(S4)).^(1/2).*u2,nu(S4)-2)-tcdf(((nu(S4)-2)./nu(S4)).^(1/2).*u1,nu(S4)-2));
  E(S4)=Ex1+Ex2+Ex3+Ex4-c1(S4);
  E(S5)=0;
  if l==1
  qt=m+w*v.^(1/2);
  [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1+w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
%a=find(a);
%ii=intersect(a,S5);
ii=a.*S5;
%if isempty(ii)==0
 %   id2=ii;
%else
if sum(ii)>0
%if 0>1
   [~,id2]=max(ii);
else
 [~,id2]=max(E);   
end
  else [~,id2]=max(E);
  end
    end
      end
  end
  pm=m(id2);
  x=Mean(id2)+(Var(id2)).^(1/2).*Nrv(i);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;
  if l==1
m2(id2)=v(id2)+(m(id2)).^2;
m3(id2)=(m3(id2).*N(id2)+x.^3)./(N(id2)+1);
m4(id2)=(m4(id2).*N(id2)+x.^4)./(N(id2)+1);
  end
  
  mu(id2)=(kappa0(id2).*mu0(id2)+N(id2).*m(id2))./(kappa0(id2)+N(id2));
  kappa(id2)=kappa0(id2)+N(id2);
  alpha(id2)=alpha0(id2)+N(id2)/2;
  beta(id2)=beta0(id2)+(N(id2)/2).*v(id2)+(kappa0(id2).*N(id2).*(m(id2)-mu0(id2)).^2)./(2*(kappa0(id2)+N(id2))); 
  V(id2)=(beta(id2)./(alpha(id2)-1)).^(1/2);
  mv=mu+w*V;
end
end
toc
end