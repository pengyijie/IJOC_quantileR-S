function [PCS,EOC]=MAP6(alpha0,c0,T,n0,num)
tic
k=length(alpha0);
PCS=zeros(1,T);
EOC=zeros(1,T);
x=zeros(T,k);
for t=1:num
a1=1./alpha0;
a2=c0./alpha0;
a3=c0.*ones(1,k);
lambda=gprnd(a1,a2,a3,1,k);
Qt=lambda;
[~,rb]=max(Qt);
x(1:n0,:)=rand(n0,k).*repmat(lambda,n0,1);
X(1,:)=c0;
X(2:n0+1,:)=x(1:n0,:);
c=max(X);
alpha=alpha0+n0;
Rv=rand(1,T);
for i=1:T
    qt=alpha.*c./(alpha-1);
  [~,id4]=max(qt);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
 E=c./(alpha-1).*(c/qt(id4)).^(alpha-1);   
  [~,id2]=max(E);  

  %N(id2)=N(id2)+1;
 alpha(id2)=alpha(id2)+1;
  c(id2)=max(c(id2),Rv(i));
end
end
toc
end