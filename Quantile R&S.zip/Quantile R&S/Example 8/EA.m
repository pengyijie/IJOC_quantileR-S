function [PCS,EOC]=EA(k,T,n0,num,p)
tic
PCS=zeros(1,T);
EOC=zeros(1,T);
%mu0=zeros(1,k);
%kappa0=zeros(1,k);
%alpha0=-1/2*ones(1,k);
%beta0=zeros(1,k);
for t=1:num
lambda=1+rand(1,k);
Qt=p*lambda;
[~,rb]=max(Qt);
N=n0*ones(1,k);
x=rand(n0,k).*repmat(lambda,n0,1);
%m=mean(x);
%v=var(x);
os=sort(x);
qe=os(fix(n0*p),:);
%w=(qe-m)./(v).^(1/2);
Rv=rand(1,T);
for i=1:T
   % if l==1
    %mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  %alpha=alpha0+N/2;
  %beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  %V=(beta./(alpha-1)).^(1/2);
  %mv=mu+w.*V;
  %[~,id4]=max(mv);
%else
   %qt=m+w.*v.^(1/2);
  [~,id4]=max(qe);
   % end
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
   ii=fix(i/k);
   if i-ii*k>0
    id2=i-ii*k;
   else
     id2=k;
   end
  x=lambda(id2)*Rv(i);
 % pm=m(id2);
 % m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  %v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;
  if qe(id2)>x
   sg=1-p;
  else
   sg=-p;
  end
  qe(id2)=qe(id2)-sg/N(id2);
  %w(id2)=(qe(id2)-m(id2))/(v(id2))^(1/2);
end
end
toc
end