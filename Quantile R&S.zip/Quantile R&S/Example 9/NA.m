function [PCS,EOC]=NA(k,T,n0,num,p,bw)
tic
PCS=zeros(1,T);
EOC=zeros(1,T);
AV=zeros(1,k);
wt=zeros(1,k);
delta=zeros(1,k);
x=zeros(T,k);
for t=1:num
lambda1=0.1+0.9*rand(1,k);
lambda2=0.1+0.9*rand(1,k);
Qt=gaminv(p*ones(1,k),lambda1,lambda2);
[~,rb]=max(Qt);
N=n0*ones(1,k);
for j=1:k
x(1:n0,j)=gamrnd(lambda1(j),lambda2(j),n0,1);
end
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
for j=1:k
AV(j)=p*(1-p)/(sum(normpdf(qt(j)*ones(1,N(j)),(x(1:N(j),j))',bw*ones(1,N(j)))))^2;
end
  %qt=m+w.*v.^(1/2);
for i=1:T

  [~,id4]=max(qt);
   
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  [~,O]=max(qt);
[~,o]=min(qt);

  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
id2=find(a);
 N(id2)=N(id2)+1;
  x(N(id2),id2)=gamrnd(lambda1(id2),lambda2(id2));
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
AV(id2)=p*(1-p)/(sum(normpdf(qt(id2)*ones(1,N(id2)),(x(1:N(id2),id2))',bw*ones(1,N(id2)))))^2;
end
end
toc
end