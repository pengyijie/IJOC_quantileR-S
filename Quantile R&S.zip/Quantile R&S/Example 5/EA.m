function [PCS,EOC]=EA(k,T,n0,num,p,l)
tic
w=norminv(p,0,1);
pn=100;
N0=1000;
B=10;
R=100;
A=8+0.1*ones(num,1)*(1:k);
U=A+(B-A).*rand(num,k);
lambda=R./(1+R./U);
m1=-(B+A(1,:))/2;
v1=(B-A(1,:)).^2/12;
m2=(m1.^2+v1)/pn;
v2=(B^4+B^3*A(1,:)+B^2.*A(1,:).^2+B*A(1,:).^3+A(1,:).^4)/5/pn^2-m2.^2;
  alpha0=m2.^2./v2+2;
  beta0=(alpha0-1).*m2;
  mu0=m1;
  kappa0=m2./v1;
  
PCS=zeros(num,T);
EOC=zeros(num,T);
x=zeros(T,k);
for t=1:num
N=n0*ones(1,k);
Qt=zeros(1,k);
%M=zeros(1,k);
for j=1:k
 x(1:n0,j)=queuing_1(lambda(t,j),R,n0,pn);
 X=queuing_1(lambda(t,j),R,N0,pn);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end
m=mean(x(1:n0,:));
v=var(x(1:n0,:));
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
%Qt=mean(X)+w*std(X);
[~,rb]=max(Qt,[],2);
for i=1:T
    if l==1
    mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1)).^(1/2);
  mv=mu+w*V;
  [~,id4]=max(mv);
else
  % qt=m+w*v.^(1/2);
  [~,id4]=max(qt);
    end
  if id4==rb
   PCS(t,i)=1;
  end
  EOC(t,i)=Qt(rb)-Qt(id4);
   ii=fix(i/k);
   if i-ii*k>0
    id2=i-ii*k;
   else
     id2=k;
   end
  N(id2)=N(id2)+1;
  x(N(id2),id2)=queuing_1(lambda(t,id2),R,1,pn);
  pm=m(id2);
  m(id2)=(m(id2).*N(id2)+x(N(id2),id2))./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x(N(id2),id2)).^2./(N(id2)+1));
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
end
end
toc
end