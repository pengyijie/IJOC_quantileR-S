function [Syst]=queuing_1(lambda,R,num,pn)
U1=rand(num,pn);
U2=rand(num,pn);
Intarr=-R*log(U1);
Serv=-lambda*log(U2);
Wait=zeros(num,pn);
for j=1:pn-1
    Wait(:,j+1)=max(0,Wait(:,j)+Serv(:,j)-Intarr(:,j));
end
Syst=-(sum(Wait,2)+sum(Serv,2))/pn;
end