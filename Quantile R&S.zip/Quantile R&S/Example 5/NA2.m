function [PCS,EOC]=NA2(k,T,n0,num,p,bw)
tic
pn=100;
N0=1000;
B=10;
R=100;
A=8+0.1*ones(num,1)*(1:k);
U=A+(B-A).*rand(num,k);
lambda=R./(1+R./U);
PCS=zeros(1,T);
EOC=zeros(1,T);
AV=zeros(1,k);
x=zeros(T,k);
for t=1:num
    N=n0*ones(1,k);
Qt=zeros(1,k);
for j=1:k
 x(1:n0,j)=queuing_1(lambda(t,j),R,n0,pn);
 X=queuing_1(lambda(t,j),R,N0,pn);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end
[~,rb]=max(Qt,[],2);
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
for j=1:k
AV(j)=p*(1-p)/(sum(normpdf(qt(j)*ones(1,N(j)),(x(1:N(j),j))',bw*ones(1,N(j)))))^2;
end
  %qt=m+w.*v.^(1/2);
for i=1:T
     [~,id4]=max(qt);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  [wt,~]=main_prog(qt,AV,10^(-2),100);
df=(k*n0+i)*wt-(k*n0+i-1)*N/sum(N);
 [~,id2]=max(df);
 N(id2)=N(id2)+1;
 x(N(id2),id2)=queuing_1(lambda(t,id2),R,1,pn);
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
AV(id2)=p*(1-p)/(sum(normpdf(qt(id2)*ones(1,N(id2)),(x(1:N(id2),id2))',bw*ones(1,N(id2)))))^2;

end
end
toc
end