function [PCS,EOC]=MAP6(k,T,n0,num,p,L)
tic
w=norminv(p,0,1);
pn=100;
N0=1000;
B=10;
R=100;
A=8+0.1*ones(num,1)*(1:k);
U=A+(B-A).*rand(num,k);
lambda=R./(1+R./U);
m1=-(B+A(1,:))/2;
v1=(B-A(1,:)).^2/12;
m2=(m1.^2+v1)/pn;
v2=(B^4+B^3*A(1,:)+B^2.*A(1,:).^2+B*A(1,:).^3+A(1,:).^4)/5/pn^2-m2.^2;
  alpha0=m2.^2./v2+2;
  beta0=(alpha0-1).*m2;
  mu0=m1;
  kappa0=m2./v1;
  
PCS=zeros(1,T);
EOC=zeros(1,T);
AV=zeros(1,k);
wt=zeros(1,k);
delta=zeros(1,k);
for t=1:num
N=n0*ones(1,k);
x=zeros(n0,k);
Qt=zeros(1,k);
%M=zeros(1,k);
for j=1:k
 x(:,j)=queuing_1(lambda(t,j),R,n0,pn);
 X=queuing_1(lambda(t,j),R,N0,pn);
  %M(j)=mean(X)+w*std(X);
 X=sort(X);
 Qt(j)=X(fix(p*N0));
end
m=mean(x);
v=var(x);
[~,rb]=max(Qt,[],2);
mu=(kappa0.*mu0+N.*m)./(kappa0+N);
  kappa=kappa0+N;
  alpha=alpha0+N/2;
  beta=beta0+(N/2).*v+(kappa0.*N.*(m-mu0).^2)./(2*(kappa0+N)); 
  V=(beta./(alpha-1/2)).^(1/2);
  pv=((1./kappa+w^2./(alpha-1/2)/2).*beta./(alpha-1)).^(1/2);
   mv=mu+w*V;
   q=max(mv);
  r=(q-mu-w*V)./pv;

m2=v+m.^2;
m3=mean(x.^3);
m4=mean(x.^4);
%U=rand(1,T);
for i=1:T
 
      [~,id4]=max(mv);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
 if i<L
    pd=(alpha./(alpha-1)).^(1/2);
 E=pv.*(pd.*tpdf(r./pd,2*alpha)-r.*(1-tcdf(r,2*alpha)));   
  [~,id2]=max(E); 
 else
   qt=m+w*v.^(1/2);
    [~,O]=max(qt);
[~,o]=min(qt);
for j=1:k
vc=[1-w*m(j)/(v(j))^(1/2),w/(v(j))^(1/2)/2];
Mx=[v(j),m3(j)-m(j)*m2(j);m3(j)-m(j)*m2(j),m4(j)-(m2(j))^2];
AV(j)=vc*Mx*vc';
end
  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
df=(k*n0+i)*wt-(k*n0+i-1)*N/sum(N);
[~,id2]=max(df);
 end
  
  pm=m(id2);
  %if length(lambda(t,id2))~=1
  %end
  x=queuing_1(lambda(t,id2),R,1,pn);
  m(id2)=(m(id2).*N(id2)+x)./(N(id2)+1);
  v(id2)=(N(id2)./(N(id2)+1)).*(v(id2)+(pm-x).^2./(N(id2)+1));
  N(id2)=N(id2)+1;

  mu(id2)=(kappa0(id2).*mu0(id2)+N(id2).*m(id2))./(kappa0(id2)+N(id2));
  kappa(id2)=kappa0(id2)+N(id2);
  alpha(id2)=alpha0(id2)+N(id2)/2;
  beta(id2)=beta0(id2)+(N(id2)/2).*v(id2)+(kappa0(id2).*N(id2).*(m(id2)-mu0(id2)).^2)./(2*(kappa0(id2)+N(id2))); 
  V(id2)=(beta(id2)./(alpha(id2)-1)).^(1/2);
   pv=((1./kappa(id2)+w^2./(alpha(id2)-1/2)/2).*beta(id2)./(alpha(id2)-1)).^(1/2);
  %pv(id2)=(beta(id2)./(alpha(id2).*kappa(id2))).^(1/2);
  mv(id2)=mu(id2)+w*V(id2);
  q=max(mv);
  r=(q-mu-w*V)./pv;
  m2(id2)=v(id2)+(m(id2)).^2;
m3(id2)=(m3(id2).*N(id2)+x.^3)./(N(id2)+1);
m4(id2)=(m4(id2).*N(id2)+x.^4)./(N(id2)+1);
  
end
end
toc
end