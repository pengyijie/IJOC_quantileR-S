function [PCS,EOC]=NA(a0,b0,T,n0,num,p,bw,s)
tic
k=length(a0);
PCS=zeros(1,T);
EOC=zeros(1,T);
AV=zeros(1,k);
wt=zeros(1,k);
delta=zeros(1,k);
x=zeros(T,k);
for t=1:num
lambda=gamrnd(a0,1./b0,1,k);
Qt=-log(1-p)./lambda;
[~,rb]=max(Qt);
N=n0*ones(1,k);
x(1:n0,:)=-log(1-rand(n0,k))./repmat(lambda,n0,1);
os=sort(x(1:n0,:));
qt=os(fix(n0*p),:);
if s>0
a=a0+n0;
b=b0-sum(log(1-rand(n0,k))./repmat(lambda,n0,1));
end
for j=1:k
AV(j)=p*(1-p)/(sum(normpdf(qt(j)*ones(1,N(j)),(x(1:N(j),j))',bw*ones(1,N(j)))))^2;
end
Rv=rand(1,T);
  %qt=m+w.*v.^(1/2);
for i=1:T

 if s>0
       r=(b./(a-1)).^(1/2);
    qe=-log(1-p).*r;
  [~,id4]=max(qe);
 else
     [~,id4]=max(qt);
 end
  
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  [~,O]=max(qt);
[~,o]=min(qt);

  Omega=setdiff((1:k),O);
  delta(Omega)=(qt(O)-qt(Omega)).^2;
AW1=(AV(Omega)*delta(o))./(AV(o).*delta(Omega));
AW2=(AV(O)./AV(Omega)).*AW1.^2;
wt(o)=1./((sum(AW2)).^(1/2)+sum(AW1));
wt(Omega)=AW1*wt(o);
wt(O)=wt(o).*(sum(AW2)).^(1/2);
e = min([0 cumsum(wt)],1);
e(end) = 1;
pr= diff(e);
a=mnrnd(1,pr);
id2=find(a);
 N(id2)=N(id2)+1;
 x(N(id2),id2)=-log(1-Rv(i))/lambda(id2);
  os=sort(x(1:N(id2),id2));
 qt(id2)=os(fix(p*N(id2)));
AV(id2)=p*(1-p)/(sum(normpdf(qt(id2)*ones(1,N(id2)),(x(1:N(id2),id2))',bw*ones(1,N(id2)))))^2;

if s>0
 a(id2)=a(id2)+1;
  b(id2)=b(id2)+x(N(id2),id2);
end
end
end
toc
end