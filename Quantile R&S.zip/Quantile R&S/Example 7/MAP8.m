function [PCS,EOC]=MAP8(a0,b0,T,n0,num,p)
tic
k=length(a0);
PCS=zeros(1,T);
EOC=zeros(1,T);
for t=1:num
lambda=gamrnd(a0,1./b0,1,k);
Qt=-log(1-p)./lambda;
[~,rb]=max(Qt);
%N=n0*ones(1,k);
a=a0+n0;
b=b0-sum(log(1-rand(n0,k))./repmat(lambda,n0,1));
Rv=rand(1,T);
for i=1:T
    r=(b./(a-1)).^(1/2);
    qt=-log(1-p).*r;
  [~,id4]=max(qt);
  if id4==rb 
  PCS(i)=PCS(i)+1/num;
  end
  EOC(i)=EOC(i)+(Qt(rb)-Qt(id4))/num;
  E=r.^2.*(gamcdf((1/r(id4))^2*ones(1,k),a-1,1./b))-(r(id4))^2*(gamcdf((1/r(id4))^2*ones(1,k),a,1./b)); 
 %E=r.*(gamcdf(1/qt(id4)*ones(1,k),a-1,1./b));   
  [~,id2]=max(E);  

  %N(id2)=N(id2)+1;
 a(id2)=a(id2)+1;
  b(id2)=b(id2)-log(1-Rv(i))/lambda(id2);
end
end
toc
end